# MRWISENPC - Static Website Templates (v2 - Light Mode Focus)

This project provides a set of static HTML, CSS, and JavaScript templates for building a website. This version focuses on:
- Light mode only (no theme toggle).
- Robust templates with placeholder content for easy modification.
- Addressed UI concerns like content collision and improved specific element designs.

## Site Structure